Steps to the code
=================
Execute EDA_Final.R prior to running models for Camera, Home and Gaming Accessories
